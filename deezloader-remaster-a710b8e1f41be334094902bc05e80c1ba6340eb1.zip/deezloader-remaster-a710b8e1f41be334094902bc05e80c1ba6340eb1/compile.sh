echo Starting to compile.
echo The software will be compiled to /dist folder
npm install && npm run dist