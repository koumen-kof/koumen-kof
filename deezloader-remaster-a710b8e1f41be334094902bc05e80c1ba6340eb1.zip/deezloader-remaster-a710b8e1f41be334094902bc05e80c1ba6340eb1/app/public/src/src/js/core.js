window.onload = function() {
	console.log("Core script loaded!");

	if (!window.jQuery) {
		console.log("jQuery is NOT loaded!");
	}
};

// JS Core code
(function ($){
	"use strict";

	$(document).on('ready', function () {

	});
})(jQuery);