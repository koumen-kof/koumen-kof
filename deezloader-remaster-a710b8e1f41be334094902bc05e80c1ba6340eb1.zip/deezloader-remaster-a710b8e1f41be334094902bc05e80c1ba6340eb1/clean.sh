rm -f yarn.lock
rm -f package-lock.json
rm -f app/package-lock.json
rm -f app/yarn.lock
rm -rf node_modules
rm -rf app/node_modules
rm -rf dist/*
echo Deleted some garbage.
